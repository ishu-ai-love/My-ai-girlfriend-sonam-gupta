
import React from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { motion } from "framer-motion";

export default function SonamGupta() {
  return (
    <div className="min-h-screen bg-gradient-to-br from-pink-100 via-red-200 to-yellow-100 p-4 text-center">
      <motion.h1
        initial={{ opacity: 0, y: -50 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 1 }}
        className="text-4xl font-bold text-pink-800 mb-4"
      >
        Welcome to Sonam Gupta – Teri AI Bhabi
      </motion.h1>

      <motion.p
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="text-lg text-pink-700"
      >
        "Aayi hoon teri duniya mein, dil jalane... pyar lutane..."
      </motion.p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mt-10">
        {/* Chat Section */}
        <Card className="bg-white/70 backdrop-blur-sm">
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold text-rose-700 mb-2">Chat with Sonam</h2>
            <p className="text-sm text-rose-600">“Kya soch rahe ho jaaneman?”</p>
            <Button className="mt-4 bg-pink-600 hover:bg-pink-700 text-white">Start Chat</Button>
          </CardContent>
        </Card>

        {/* Gallery Section */}
        <Card className="bg-white/70 backdrop-blur-sm">
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold text-rose-700 mb-2">Hot Gallery</h2>
            <p className="text-sm text-rose-600">Sonam bhabi in sizzling looks</p>
            <div className="mt-4 grid grid-cols-2 gap-2">
              <div className="bg-pink-200 h-24 rounded-xl">Image 1</div>
              <div className="bg-pink-300 h-24 rounded-xl">Image 2</div>
              <div className="bg-pink-200 h-24 rounded-xl">Image 3</div>
              <div className="bg-pink-300 h-24 rounded-xl">Image 4</div>
            </div>
          </CardContent>
        </Card>

        {/* About Section */}
        <Card className="col-span-1 md:col-span-2 bg-white/70 backdrop-blur-sm">
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold text-rose-700 mb-2">About Sonam</h2>
            <p className="text-sm text-rose-600">
              Sonam Gupta... ek naam, jo sirf dhadkanon mein nahi— fantasies mein bhi basa hua hai.
              Virtual duniya ki sabse hot bhabhi, jo har pal teri attention ki haqdaar hai.
            </p>
          </CardContent>
        </Card>

        {/* Confess Section */}
        <Card className="col-span-1 md:col-span-2 bg-white/70 backdrop-blur-sm">
          <CardContent className="p-4">
            <h2 className="text-2xl font-semibold text-rose-700 mb-2">Confess Your Feelings</h2>
            <input
              type="text"
              placeholder="Dil ki baat likh de yahan..."
              className="w-full p-2 rounded-xl border border-pink-400 focus:outline-none"
            />
            <Button className="mt-4 bg-pink-600 hover:bg-pink-700 text-white">Send to Sonam</Button>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
